interface = ":"
user = "Q"
bot = "A"

init_prompt = f'''
Expert Questions & Helpful Answers

Ask Research Experts
'''